# Developer Handoff — Apply v5.1 PDF Template (URGENT)

## The problem (was)

The "after" PDF you generated for Dr. Mandar Shah was identical to the "before" PDF because **the v5 template was not applied to your `/api/report` code**. You were still rendering the old template.

This handoff covers v5.1 — which extends v5 with two NEW pages: Social Media Content Engine + Production & Compliance Guide.

**See the file `DocMirror-v5-SAMPLE-Mandar-Shah.pdf`** in this package. That's the same doctor (Dr. Mandar Shah) rendered through the v5.1 template. 15 pages now, including the new social content strategy with 30-day calendar and the compliance guide.

---

## What's new in v5.1 (Page 10 + 11)

### Page 10: Social Media Content Engine
- 4-category content map: Education, Lifestyle, Behind the Practice, Community
- 12 sub-categories with specific topic ideas (specialty + location aware)
- 30-day visual posting calendar (Mon/Wed/Fri)
- 12-topic ready-to-film library
- Platform mix (Instagram, YouTube Shorts, WhatsApp Business)

### Page 11: Production & Compliance Guide
- Shoot production tips (lighting, framing, wardrobe, audio with INR pricing)
- Caption framework (Hook → Value → CTA → Disclaimer → Hashtags)
- Universal medical compliance rules (6 don'ts)
- Specialty-specific cautions (region + specialty aware)
- Pre-publish checklist (10-item)

---

## What to do today (1-2 hours of work)

### Step 1: Replace the PDF template file

In your repo, replace `frontend/pdf-report-template.html` with the v5.1 file from this package.

The new template is now ~1100 lines, 15 pages. Placeholder tokens documented at the top of the file.

### Step 2: Update `/api/report` to use `buildPdfPlaceholders()`

```typescript
import { buildPdfPlaceholders, validatePillarTotal } from '@/lib/audit'

export async function POST(req: Request) {
  const { auditId } = await req.json()
  const audit = await getAuditFromCache(auditId)

  // CRITICAL: validate before generating
  const v = validatePillarTotal(audit)
  if (!v.valid) {
    return Response.json({ error: 'Report calculation failed' }, { status: 500 })
  }

  let html = await fs.readFile('frontend/pdf-report-template.html', 'utf8')
  const placeholders = buildPdfPlaceholders(audit, 15)  // NEW: 15 pages, not 13
  for (const [token, value] of Object.entries(placeholders)) {
    html = html.replaceAll(token, value)
  }

  if (html.match(/\{\{[A-Z_]+\}\}/)) {
    return Response.json({ error: 'Template error' }, { status: 500 })
  }

  const pdf = await htmlPdf.generatePdf({ content: html }, { format: 'A4', printBackground: true })
  return Response.json({ success: true })
}
```

### Step 3: Add 2 new Claude prompts (v5.1)

In your Claude orchestration code (where you call all prompts in parallel), add two more:

```typescript
const [issues, fixes, sentiment, narrative, journey, plan, execSummary, responseTemplates,
       socialContent, specialtyDonts] = await Promise.all([
  callClaude(CLAUDE_PROMPTS.issues(audit)),
  callClaude(CLAUDE_PROMPTS.fixes(audit)),
  callClaude(CLAUDE_PROMPTS.sentiment(audit.recentReviews)),
  callClaude(CLAUDE_PROMPTS.competitorNarrative(audit, audit.competitors)),
  callClaude(CLAUDE_PROMPTS.patientJourney(audit)),
  callClaude(CLAUDE_PROMPTS.ninetyDayPlan(audit)),
  callClaude(CLAUDE_PROMPTS.execSummary(audit)),
  callClaude(CLAUDE_PROMPTS.responseTemplates(audit, sentiment)),
  callClaude(CLAUDE_PROMPTS.socialContentStrategy(audit)),     // NEW v5.1
  callClaude(CLAUDE_PROMPTS.specialtyComplianceDonts(audit)),  // NEW v5.1
])

audit.socialContent = socialContent
audit.specialtyDonts = specialtyDonts.donts
audit.complianceFramework = audit.region === 'IN'
  ? 'MCI Code, IMC Regulations 2002, and the Drug & Magic Remedies Act 1954'
  : 'FTC, FDA Guidance, and HIPAA'
audit.hashtagLocation = `${audit.city.replace(/\s/g, '')}${audit.specialty.replace(/\s/g, '')}`
audit.hashtagSpecialty = audit.specialty.replace(/\s/g, '')
```

### Step 4: Update the helper functions in api-spec.ts

The new placeholders need rendering helpers. See `populate_template.py` in this package for the exact HTML structure each function should produce. Specifically:

- `subcats_html(subcats)` — renders a category card's sub-categories
- `calendar_html(weeks)` — renders the 30-day grid
- `topic_library_html(topics)` — renders the topic chips
- `specialty_donts_html(donts)` — renders the cardiologist-specific cautions

Python and TypeScript implementations are functionally identical — port directly.

---

## How to verify it worked

1. Generate a PDF for any test doctor.
2. Confirm it has **15 pages**, not 13.
3. Confirm Page 10 has the Social Media Content Engine with 4 category cards, 30-day calendar, 12-topic library.
4. Confirm Page 11 has the Production & Compliance Guide with red compliance box + yellow specialty cautions + green checklist.
5. Confirm specialty-appropriate content: psychiatrists never get "before/after photo" topics, pediatricians never get patient imagery suggestions.
6. Confirm region awareness: Indian doctors see ₹ pricing and reference Indian directories/festivals; US doctors see $ and US contexts.

---

**Questions:** hello@thedocmirror.com
